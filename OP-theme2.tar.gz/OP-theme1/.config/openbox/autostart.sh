#!/bin/bash

#feh --bg-scale /usr/share/lxde/Fondos/6.jpg &
nitrogen --restore &
#tint2 -c /home/ISO/.config/tint2/lanzador1.tint2rc &
tint2 -c /home/ISO/.config/tint2/Dock.tint2rc &
slepp 1
tint2 &