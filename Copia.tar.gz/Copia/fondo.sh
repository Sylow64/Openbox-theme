#!/bin/bash8
pcmanfm --set-wallpaper /usr/share/lxde/Fondos/8.jpg --wallpaper-mode=crop
if pgrep plank; then
pkill plank &
fi
if pgrep lxpanel; then
killall lxpanel &
fi
if ! pgrep picom; then
picom --config /opt/Loc-OScc/themes/picom.conf &
fi
tint2 -c $HOME/.config/tint2/Fino.tint2rc &


