#! /bin/bash
/home/ISO/.config/rofi/rofi/powermenu &