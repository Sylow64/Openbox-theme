#!/bin/bash
 
nitrogen --restore &
tint2 &
xfce4-clipman &
#picom --config ~/.config/picom/picom2.conf &
picom --config ~/.config/picom/joan2.conf --experimental-backend &