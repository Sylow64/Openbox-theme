#!/bin/bash
jgmenu_run init
rm -r $HOME/.config/jgmenu/*
pkill picom
pkill tint2
cp -fR /opt/Loc-OScc/themes/Minimo/.config/* $HOME/.config
cp -fR /opt/Loc-OScc/Minimo/.themes/* $HOME/.themes
cp -fR /opt/Loc-OScc/themes/Minimo/.icons/* $HOME/.icons
pcmanfm --desktop-off
openbox --restart
lxpanelctl restart
sleep 1
pcmanfm --desktop -p LXDE &
sleep 1
sh /opt/Loc-OScc/themes/Minimo/fondo.sh
